﻿using System;

namespace DataStructures.RopeSpace
{
    [Serializable]
    public partial class Rope
    {

    }
}
